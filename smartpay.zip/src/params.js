const Params = {
    FunctionKey: {
        SEND_NO_CR: 1,
        SEND_CR: 2,
        NO_SEND_OUT: 3,
        DO_SEND_OUT: 4,
    }
};

module.exports = Params