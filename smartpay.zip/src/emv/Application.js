class Application {
  constructor() {
    this.logs = null;
  }
}
module.exports = Application;
